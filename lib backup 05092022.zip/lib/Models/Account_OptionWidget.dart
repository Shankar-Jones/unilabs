import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'Theme.dart';


class AccountOptionWidget extends StatelessWidget {
  final IconUrl;
  final text;
  final OnTap;



  const AccountOptionWidget({Key? key,required this.IconUrl,required this.text, required this.OnTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
      InkWell(
        onTap: OnTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 11.0,),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  SvgPicture.asset(IconUrl),

                  SizedBox(width: 10,),

                  Text(text,style: TextStyle(  fontFamily: 'archivo'),),

                ],
              ),
              Icon(
                Icons.keyboard_arrow_right_outlined,
              ),
            ],
          ),
        ),
      );
  }
}
