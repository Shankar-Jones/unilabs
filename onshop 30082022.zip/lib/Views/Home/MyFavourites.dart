import 'package:flutter/material.dart';
import 'package:onshop/Models/AppBar_Widgets.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';



String  favourite = '';

class MyFavourites extends StatefulWidget {
  const MyFavourites({Key? key}) : super(key: key);

  @override
  _MyFavouritesState createState() => _MyFavouritesState();
}

class _MyFavouritesState extends State<MyFavourites> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Column(
          children: [
            Center(
                child: HeadingPoppins(text: 'My Favourites')),
            SizedBox(height: 30),
            GridView(
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                physics: BouncingScrollPhysics(),


                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 8,
                    mainAxisSpacing:8
                ),
                children:  [
                  for(int i=0; i<12; i++)
                    InkWell(
                        onTap: (){
                          setState(() {
                              favourite = '${i}';
                        });
                            },
                        child:  Container(
                          width: 160,height: 200,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: UiColors.primaryShade
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(3),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(

                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(4.0),
                                    child: Icon(favourite == '${i}' ? Icons.favorite:Icons.favorite_border_outlined,size: 18,color:favourite == '${i}'? Colors.red: UiColors.primary,),
                                  ),
                                ),
                                Center(
                                  child: Container(
                                      height: 100,
                                      child: Image.network('https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',fit: BoxFit.fill)),
                                ),
                                Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 8,top: 5,bottom: 2),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text('Armchair',style: TextStyle(fontFamily: 'archivo bold'),),
                                          SizedBox(height: 3,),
                                          Row(
                                            children: [
                                              Text('\u{20B9}3,239',style: TextStyle(fontFamily: 'archivo bold',color: UiColors.primary,fontWeight: FontWeight.bold),),
                                              Text('48%',style: TextStyle(color: UiColors.primary),),
                                            ],
                                          ),

                                        ],
                                      ),
                                    ))
                              ],
                            ),
                          ),

                        )),


              //    ProductCardSec(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon:favourite ? Icons.favorite:Icons.favorite_border_outlined,productRate: '3,322')
                ]

            ),
          ],
        ));
  }

}
