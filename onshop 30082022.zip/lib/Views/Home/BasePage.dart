import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/MedButton.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:onshop/Views/Home/Categories.dart';
import 'package:onshop/Views/Home/Home.dart';
import 'package:onshop/Views/Home/MyAccount.dart';
import 'package:onshop/Views/Home/MyCart.dart';
import 'package:onshop/Views/Home/MyFavourites.dart';

import '../../Models/Account_OptionWidget.dart';
import 'ProductDetails.dart';


String ActivePage='home';
bool favorite = false;
class BaseScreen extends StatefulWidget {
  const BaseScreen({Key? key}) : super(key: key);

  @override
  _BaseScreenState createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                SizedBox(height:20),
                if(ActivePage=='home')
                HomeScreen(),
                if(ActivePage=='profile')
                MyAccount(),
                if(ActivePage=='category')
                  Categories(),
                if(ActivePage=='mycart')
                  MyCart(),
                if(ActivePage=='favourite')
                  MyFavourites(),
              ],
            ),
          ),
        ),
          bottomNavigationBar: Container(
            height: 70,
            decoration: BoxDecoration(
              color: UiColors.primaryShade,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(25),topRight: Radius.circular(25))
            ),
            child: Center(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  GestureDetector(
                    onTap: (){
                      setState(() {
                        ActivePage='home';
                      });
                    },
                      child:ActivePage == 'home' ? SvgPicture.asset('assets/homepage/Home_active.svg',height: 45 ) : SvgPicture.asset('assets/homepage/Home_inactive.svg',height: 45 )),
                  GestureDetector(
                      onTap: (){
                        setState(() {
                          ActivePage='category';
                        });
                      },
                      child:ActivePage == 'category' ? SvgPicture.asset('assets/homepage/Category_active.svg',height: 45  ): SvgPicture.asset('assets/homepage/Category_inactive.svg',height: 45  )),
                  GestureDetector(
                      onTap: (){
                        setState(() {
                          ActivePage='mycart';
                        });
                      },
                      child: ActivePage == 'mycart' ? SvgPicture.asset('assets/homepage/Mycart__active.svg',height: 45  ): SvgPicture.asset('assets/homepage/Mycart__inactive.svg',height: 45  )),
                  GestureDetector(
                      onTap: (){
                        setState(() {
                          ActivePage='favourite';
                        });
                      },
                      child: ActivePage == 'favourite' ? SvgPicture.asset('assets/homepage/Favourite_active.svg',height: 45  ): SvgPicture.asset('assets/homepage/Favourite_inactive.svg',height: 45  )),
                  GestureDetector(
                      onTap: (){
                        setState(() {
                          ActivePage='profile';
                        });
                      },
                      child: ActivePage == 'profile' ? SvgPicture.asset('assets/homepage/Profil_active.svg',height: 45  ): SvgPicture.asset('assets/homepage/Profil_inactive.svg',height: 45  )),

                ],
              ),
            ),
          ),
        ));
  }

}
