import 'package:flutter/material.dart';
import 'package:onshop/Models/AppBar_Widgets.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:expandable/expandable.dart';

import '../../Models/HeadingText.dart';
import '../../Models/MedButton.dart';

class Categories extends StatefulWidget {
  const Categories({Key? key}) : super(key: key);

  @override
  _CategoriesState createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
            child: HeadingPoppins(text: 'Categories')),
        SizedBox(height: 30),
        CategoryProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),
        CategoryProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),

        CategoryProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),
        CategoryProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),

        CategoryProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),
        CategoryProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg', startingRate: '200', itemsCount: '200', productName: 'Arms chair'),



      ],

    );
  }

}
