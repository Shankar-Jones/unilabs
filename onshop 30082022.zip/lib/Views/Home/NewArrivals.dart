import 'package:flutter/material.dart';
import 'package:onshop/Models/AppBar_Widgets.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:expandable/expandable.dart';

import '../../Models/HeadingText.dart';
import '../../Models/MedButton.dart';

class NewArrivals extends StatefulWidget {
  const NewArrivals({Key? key}) : super(key: key);

  @override
  _NewArrivalsState createState() => _NewArrivalsState();
}

class _NewArrivalsState extends State<NewArrivals> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: shopappBar('New Arrivals',context),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [

                  GridView(
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  physics: BouncingScrollPhysics(),


                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 10,
                      mainAxisSpacing:10.0
                  ),
                  children:  [
                    for(int i=0; i<12; i++)
                    ProductCardSec(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                    ProductCardSec(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),


                  ]

              ),
                ],
              ),
            ),
          ),
        ));
  }

}
