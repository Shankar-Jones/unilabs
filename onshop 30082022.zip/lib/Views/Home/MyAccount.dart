import 'package:flutter/material.dart';
import 'package:onshop/Models/Account_OptionWidget.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/MedButton.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:flutter_svg/flutter_svg.dart';




class MyAccount extends StatefulWidget {
  const MyAccount({Key? key}) : super(key: key);

  @override
  State<MyAccount> createState() => _MyAccountState();
}

class _MyAccountState extends State<MyAccount> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Center(
            child: HeadingText1(text: 'My Account',)),
        SizedBox(height:30),



        Container(
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
              color: UiColors.primary,
              borderRadius: BorderRadius.circular(8)
          ),
          child: Column(
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 25,
                        foregroundImage: AssetImage('assets/profile.jpg'),
                      ),
                      SizedBox(width: 10,),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,

                        children: [
                          Text('Jenny Dwane',style: TextStyle(color: Colors.white,fontSize: 18,fontFamily: 'poppins'),),
                          SizedBox(height: 7,),
                          Text(' UI/UX Developer',style: TextStyle(color: Colors.white70,fontSize: 13)),
                        ],
                      )
                    ],
                  ),
                  SvgPicture.asset('assets/svgs/Edit.svg',height: 25,),
                ],
              ),
              SizedBox(height: 20),
              Row(
                children: [
                  SvgPicture.asset('assets/svgs/mobile.svg',height: 19,),
                  SizedBox(width: 7,),
                  Text('+91 9876543210',style: TextStyle(color: Colors.white70, )),

                ],
              ),
              SizedBox(height: 6),
              Row(
                children: [
                  SvgPicture.asset('assets/svgs/mail.svg',height: 19,),
                  SizedBox(width: 7,),
                  Text('examplemail@yahoo.com',style: TextStyle(color: Colors.white70, )),

                ],
              ),
              SizedBox(height: 5),

            ],
          ),
        ),


        SizedBox(height:20),
        Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: UiColors.primaryShade,
              borderRadius: BorderRadius.circular(8)
          ),
          child: Column(
            children: [
              AccountOptionWidget(IconUrl: 'assets/svgs/AddressInfo.svg', text: 'My Orders', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/Notification.svg', text: 'Notification', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/Myorder.svg', text: 'My Wishlist', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/AddressInfo.svg', text: 'Address info', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/PaymentMethod.svg', text: 'Payment Method', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/GiftVoucher.svg', text: 'Gift Vouchers', OnTap: (){},),
              AccountOptionWidget(IconUrl: 'assets/svgs/Help.svg', text: 'Help', OnTap: (){},),



            ],
          ),
        ),
        SizedBox(height:20),
        UiButton(text: 'Logout', ontap: (){}),
        SizedBox(height:20),

      ],
    );
  }
}
