 import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:onshop/Controllers/Constants.dart';


 PostMethod(urllink,jsonvalue) async {
 var urls = "${ConstantsN.baseurl}/${urllink}";
    var responses = await http.post(Uri.parse(urls), headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
        body:  jsonvalue
    );
    print(responses.body);
      List userdata = json.decode(responses.body);
      print(userdata);
      return userdata;
 }
   

 PutMethod(urllink,jsonvalue) async {
 var urls1 = "${ConstantsN.baseurl}/${urllink}";
    var responses = await http.put(Uri.parse(urls1), headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
        body:  jsonvalue
    );
      List data = json.decode(responses.body);
      print(data);
      return data;
 }

 GetMethod(urllink) async{
     var response2 = await http.get(Uri.parse(
                        "${ConstantsN.baseurl}/${urllink}"),
                        headers: {
                          "Accept": "application/json", 
                        }
                    );

                   List getdata = json.decode(response2.body);
                   return getdata;

 }  
 
 DeleteMethod(urllink) async{
     var response3 = await http.delete(Uri.parse(
                        "${ConstantsN.baseurl}/${urllink}"),
                        headers: {
                          "Accept": "application/json", 
                        }
                    );

                   List deletedata = json.decode(response3.body);
                   return deletedata;

 }  