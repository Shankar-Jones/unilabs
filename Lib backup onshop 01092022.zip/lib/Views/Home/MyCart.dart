import 'package:flutter/material.dart';
import 'package:onshop/Models/MedButton.dart';

import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';


import '../../Models/HeadingText.dart';


class MyCart extends StatefulWidget {
  const MyCart({Key? key}) : super(key: key);

  @override
  _MyCartState createState() => _MyCartState();
}

class _MyCartState extends State<MyCart> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Center(
            child: HeadingPoppins(text: 'My Cart')),
        SizedBox(height: 30),
        for(int i=0; i<3; i++)
        Container(
          margin: EdgeInsets.only(bottom: 10),
          height: 120,
          width: MediaQuery.of(context).size.width*0.90,

          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: UiColors.primaryShade
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                        width: MediaQuery.of(context).size.width*0.28,

                        child: Image.network('https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png',fit: BoxFit.fill)),
                    SizedBox(width: 0),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.max,
                          children:[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 5,),
                                Text('Arms chair',style: TextStyle(fontFamily: 'poppins bold',fontSize: 17),),
                                Text('Brand name',style: TextStyle(fontSize: 13,color: Colors.grey,fontFamily: 'archivo bold',),)
                              ],
                            ),

                            Text('\u{20B9}3,289',style: TextStyle(fontFamily: 'archivo bold',fontSize: 17),),

                          ] ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      child: Icon(
                        Icons.highlight_off_outlined,
                      ),
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(

                              contentPadding: EdgeInsets.all(12),
                              content: StatefulBuilder(
                                  builder: (BuildContext context, StateSetter setState) {
                                    return Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SafeArea(
                                        child: Container(


                                          margin: const EdgeInsets.all(8.0),

                                          child:  Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              SizedBox(height: 10,),
                                              Row(crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Text('Are you sure, \nYou want to remove this item?',style: TextStyle(fontFamily: 'poppins medium'),textAlign: TextAlign.center,),

                                                ],
                                              ),
                                              SizedBox(height: 30,),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  UiCancelButtom(text: ' Cancel ', ontap: (){
                                                    Closepop(context);
                                                  },),
                                                  SizedBox(width: 15,),
                                                  UiButtonSec(text: 'Remove ', ontap: (){}),



                                                ],
                                              ),
                                              SizedBox(height: 10,),


                                            ],
                                          ),
                                        ),
                                      ),
                                    );

                                  }),
                            );
                          },
                        );
                    },
                    ),
                    Container(
                        alignment: Alignment.centerRight,
                        decoration: BoxDecoration(

                            color: UiColors.primarySec,
                            borderRadius: BorderRadius.circular(100)
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5.0,horizontal: 6),
                          child: Row(
                            children: [
                              Container(
                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Icon(Icons.remove,color: Colors.black,size: 15,),
                                  )
                              ),
                              SizedBox(width: 15,),
                              Text('2',style: TextStyle(fontFamily: 'Archivo bold',fontSize: 13),),
                              SizedBox(width: 15,),
                              Container(

                                  decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: Colors.white
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Icon(Icons.add,color: Colors.black,size: 15,),
                                  )
                              ),
                            ],
                          ),
                        )
                    ),
                  ],
                )

              ],
            ),
          ),

        ),

        SizedBox(height: 30),
        Container(



          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: UiColors.primaryShade
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child:  Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                        Text('Subtotal'),
                        Text('\u{20B9}9,876',style:TextStyle(fontFamily: 'archivo bold')),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(6.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                        Text('Shipping charge'),
                        Text('Free',style:TextStyle(fontFamily: 'archivo bold',color: Colors.red)),
                    ],
                  ),
                ),

                Divider(),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total',style:TextStyle(fontFamily: 'archivo bold',fontSize: 15)),
                      Text('\u{20B9} 9,987',style:TextStyle(fontFamily: 'archivo bold',fontSize: 15)),
                    ],
                  ),
                ),
              ],
            ),
          ),

        ),

        SizedBox(height: 30),
        UiButton(text: 'Checkout', ontap: (){}),
        SizedBox(height: 30),

      ],

    );
  }

}
