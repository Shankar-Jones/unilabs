import 'package:flutter/material.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:onshop/Views/Home/ProductDetails.dart';

import 'CategoryWise_Products.dart';
import 'NewArrivals.dart';
import 'Notifications.dart';

String category='1';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState(){
           category='1';

    super.initState();
  }
  @override
  void dispose(){
    category='1';
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  foregroundImage: AssetImage('assets/profile.jpg'),
                ),
                SizedBox(width: 20,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Welcome',style: TextStyle(color: Colors.black54,)),
                    Text('Jack Jones',style: TextStyle(color: Colors.black,fontSize: 17),),
                  ],
                )
              ],
            ),
            InkWell(
                onTap: (){
                  PushNavigator(context, MyNotifications());
                },
                child: SvgPicture.asset('assets/homepage/notification.svg',height: 25,)),
          ],
        ),
        SizedBox(height:15),


        Padding(
          padding: const EdgeInsets.symmetric(horizontal:  0,vertical: 13),
          child: Container(
            height: 50,
            decoration: BoxDecoration(
                color: UiColors.primaryShade,
                borderRadius: BorderRadius.circular(9)
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 0),
                child: TextFormField(
                  style: TextStyle(fontSize: 16),
                  decoration: InputDecoration(
                    hintText: ' Search your product...',
                    hintStyle: TextStyle(color:Colors.grey[400],fontSize: 15),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
          ),
        ),
        SizedBox(height:10),

        HeadingText1(text: 'Categories'),
        SizedBox(height:15),

        Container(
          width: double.infinity,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child:Row(
              children: [
                GestureDetector(
                  onTap: (){
                    setState(() {
                      category='1';
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color:category=='1' ? UiColors.primary : UiColors.primaryShade ,
                          borderRadius: BorderRadius.circular(7)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                        child: Text('All',style: TextStyle(color:category=='1' ? Colors.white :Colors.black),),
                      ),
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: (){
                    setState(() {
                      category='2';
                      PushNavigator(context, CategoryWiseProducts(Category: 'chairs',));
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color:category=='2' ? UiColors.primary : UiColors.primaryShade ,
                          borderRadius: BorderRadius.circular(7)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                        child: Text('Chair',style: TextStyle(color:category=='2' ? Colors.white :Colors.black),),
                      ),
                    ),
                  ),
                ),

                GestureDetector(
                  onTap: (){
                    setState(() {
                      category='3';
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color:category=='3' ? UiColors.primary : UiColors.primaryShade ,
                          borderRadius: BorderRadius.circular(7)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                        child: Text('Sofa',style: TextStyle(color:category=='3' ? Colors.white :Colors.black),),
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: (){
                    setState(() {
                      category='4';
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 10.0),
                    child: Container(
                      decoration: BoxDecoration(
                          color:category=='4' ? UiColors.primary : UiColors.primaryShade ,
                          borderRadius: BorderRadius.circular(7)
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                        child: Text('Table',style: TextStyle(color:category=='4' ? Colors.white :Colors.black),),
                      ),
                    ),
                  ),
                ),



              ],
            ),
          ),
        ),

        SizedBox(height:20),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            HeadingText1(text: 'New Arrivals'),
            InkWell(
              onTap: () {
                PushNavigator(context,NewArrivals());

              },
              child: Row(
                children: [
                  Text('Show all',style: TextStyle(color: UiColors.primary,),),
                  Icon(Icons.keyboard_arrow_right_outlined,color: UiColors.primary,)
                ],
              ),
            )
          ],
        ),

        SizedBox(height:20),

        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: BouncingScrollPhysics(),
          child: Row(
            children: [
              InkWell(
                  onTap: (){
                    PushNavigator(context,ProductDetails(data: null));

                  },
                  child: ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322')),
              ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),


            ],
          ),
        ),
        SizedBox(height:20),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            HeadingText1(text: 'Best Sellers'),
            Row(
              children: [
                Text('Show all',style: TextStyle(color: UiColors.primary,),),
                Icon(Icons.keyboard_arrow_right_outlined,color: UiColors.primary,)
              ],
            )
          ],
        ),

        SizedBox(height:20),

        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: BouncingScrollPhysics(),
          child: Row(
            children: [

              ProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
              ProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png',productName: 'Armchair',productPercentage: 48,icon:Icons.favorite_border_outlined ,productRate: '3,322'),

            ],
          ),
        ),
        SizedBox(height:20),

      ],
    );
  }
}
