import 'package:flutter/material.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:expandable/expandable.dart';

import '../../Models/MedButton.dart';

class ProductDetails extends StatefulWidget {
  final data;
  const ProductDetails({Key? key,this.data}) : super(key: key);

  @override
  _ProductDetailsState createState() => _ProductDetailsState();
}

class _ProductDetailsState extends State<ProductDetails> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
              child: Scaffold(
                backgroundColor: Colors.white,
                appBar: AppBar(
                  elevation: 0,
                  backgroundColor: Colors.white,
                  title: HeadingPoppins(text: 'Product name'),

                  centerTitle: true,
                  leading: IconButton(
                    onPressed: (){
                      Navigator.pop(context);
                    },icon: Icon(Icons.arrow_back_ios),),
                ),
                body: SingleChildScrollView(
                  child: Column(
                    children: [
                      Container(
                        height: MediaQuery.of(context).size.height*0.35,
                          width: double.infinity,
                          child: Center(child: Image.network('https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',fit: BoxFit.fitWidth,))),
                     SizedBox(height: 10,),
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: UiColors.primaryShade,
                          borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20)),
                        ),
                        width: double.infinity,
                        height: MediaQuery.of(context).size.height*0.6,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 10),
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                      Text('Armchair',style: TextStyle(fontSize: 23,fontFamily: 'Archivo bold'),),
                                      SizedBox(height: 5),
                                      Text('Brand Name',style: TextStyle(fontSize: 15,color: Colors.black54),),
                                      ],
                                    ),

                                    Container(

                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.white
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.all(6.0),
                                        child: Icon(Icons.favorite_border_outlined,size: 20,color: UiColors.primary,),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(

                                      decoration: BoxDecoration(

                                        color: UiColors.primarySec,
                                        borderRadius: BorderRadius.circular(100)
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(vertical: 5.0,horizontal: 6),
                                        child: Row(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.white
                                              ),
                                              child: Padding(
                                                padding: const EdgeInsets.all(5.0),
                                                child: Icon(Icons.remove,color: Colors.black,size: 19,),
                                              )
                                            ),
                                            SizedBox(width: 25,),
                                            Text('2',style: TextStyle(fontFamily: 'Archivo bold',fontSize: 17),),
                                            SizedBox(width: 25,),
                                            Container(
                                                decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Colors.white
                                                ),
                                                child: Padding(
                                                  padding: const EdgeInsets.all(5.0),
                                                  child: Icon(Icons.add,color: Colors.black,size: 19,),
                                                )
                                            ),
                                          ],
                                        ),
                                      )
                                    ),
                                    Text('\u{20B9}3,329',style: TextStyle(fontSize: 20,fontFamily: 'Archivo bold'),),





                                  ],
                                ),
                                SizedBox(height: 10,),
                                Divider( thickness: 1,color: UiColors.primarySec,),
                                ExpandableNotifier(
                                    child: Column(
                                      children: <Widget>[

                                        ScrollOnExpand(
                                          scrollOnExpand: true,
                                          scrollOnCollapse: false,
                                          child: ExpandablePanel(
                                            theme: const ExpandableThemeData(
                                              headerAlignment: ExpandablePanelHeaderAlignment.center,
                                              tapBodyToCollapse: true,
                                            ),
                                            header: Padding(
                                                padding: EdgeInsets.all(2),
                                                child: Text('Product Detail',style: TextStyle(fontFamily: 'Archivo bold',fontSize: 15),),),
                                            collapsed: SizedBox(),
                                            expanded: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: <Widget>[

                                                Padding(
                                                  padding: EdgeInsets.only(bottom: 10),
                                                  child:Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum led it to make a type specimen book",style: TextStyle(color: Colors.black54,fontFamily: 'poppins'),),
                                                ),
                                              ],
                                            ),
                                            builder: (_, collapsed, expanded) {
                                              return Padding(
                                                padding: EdgeInsets.only(left: 10, right: 10, bottom: 2),
                                                child: Expandable(
                                                  collapsed: collapsed,
                                                  expanded: expanded,
                                                  theme: const ExpandableThemeData(crossFadePoint: 0),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ],
                                    )),

                                Divider( thickness: 1,color: UiColors.primarySec,),
                                ExpandableNotifier(
                                    child: Column(
                                      children: <Widget>[

                                        ScrollOnExpand(
                                          scrollOnExpand: true,
                                          scrollOnCollapse: false,
                                          child: ExpandablePanel(
                                            theme: const ExpandableThemeData(
                                              headerAlignment: ExpandablePanelHeaderAlignment.center,
                                              tapBodyToCollapse: true,
                                            ),
                                            header: Padding(
                                              padding: EdgeInsets.all(2),
                                              child: Text('Primary Colors',style: TextStyle(fontFamily: 'Archivo bold',fontSize: 15),),),
                                            collapsed: SizedBox(),
                                            expanded:  Padding(
                                              padding: const EdgeInsets.all(8.0),
                                              child: Row(
                                                children: [
                                                  Container(
                                                    decoration:BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        border: Border.all()
                                                    ),
                                                    child: Padding(
                                                      padding: const EdgeInsets.all(4.0),
                                                      child: Container(
                                                        decoration: BoxDecoration(
                                                            shape: BoxShape.circle,
                                                            color: Colors.red
                                                        ),
                                                        height: 25,width: 25,
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(width: 15,),
                                                  Container(
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Colors.blue
                                                    ),
                                                    height: 25,width: 25,
                                                  ),
                                                  SizedBox(width: 15,),
                                                  Container(
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Colors.green
                                                    ),
                                                    height: 25,width: 25,
                                                  ),
                                                  SizedBox(width: 15,),
                                                  Container(
                                                    decoration: BoxDecoration(
                                                        shape: BoxShape.circle,
                                                        color: Colors.limeAccent
                                                    ),
                                                    height: 25,width: 25,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            builder: (_, collapsed, expanded) {
                                              return Padding(
                                                padding: EdgeInsets.only(left: 10, right: 10,top:2,bottom: 2 ),
                                                child: Expandable(
                                                  collapsed: collapsed,
                                                  expanded: expanded,
                                                  theme: const ExpandableThemeData(crossFadePoint: 0),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                      ],
                                    )),


                                Divider( thickness: 1,color: UiColors.primarySec,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                      Text('Review',style: TextStyle(fontFamily: 'Archivo bold',fontSize: 15),),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.star_outlined,size: 18,color: UiColors.primary,
                                        ),
                                        Icon(
                                          Icons.star_outlined,size: 18,color: UiColors.primary,
                                        ),
                                        Icon(
                                          Icons.star_outlined,size: 18,color: UiColors.primary,
                                        ),

                                        Icon(
                                          Icons.star_border_outlined,size: 18,color: UiColors.primary,
                                        ),
                                        Icon(
                                          Icons.star_border_outlined,size: 18,color: UiColors.primary,
                                        ),
                                        Text('  (1500) '),
                                        Icon(Icons.keyboard_arrow_right_outlined),
                                        SizedBox(width: 5,),

                                      ],
                                    )
                                  ],
                                ),
                                SizedBox(height: 30,),

                                UiButton(text: 'Add to Cart', ontap: (){},)

                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ));
  }
}
