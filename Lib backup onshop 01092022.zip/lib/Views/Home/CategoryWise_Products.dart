import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:onshop/Models/MedButton.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';


String _chosenValue='Min';
String _chosenValueTwo='15,000';

class CategoryWiseProducts extends StatefulWidget {
  final Category;
  const CategoryWiseProducts({Key? key,this.Category}) : super(key: key);

  @override
  _CategoryWiseProductsState createState() => _CategoryWiseProductsState();
}

class _CategoryWiseProductsState extends State<CategoryWiseProducts> {
  RangeValues _values = RangeValues(0.3, 0.7);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            elevation: 0,
            backgroundColor: Colors.white,
            title: Text(widget.Category,style: TextStyle(fontSize: 17.5,fontFamily: 'poppins'),),
            centerTitle: true,
            leading: IconButton(
              onPressed: (){
                Navigator.pop(context);
              },icon: Icon(Icons.arrow_back_ios),),
            actions: [
             IconButton(
                 onPressed: (){
                   showModalBottomSheet<void>(
                     shape: RoundedRectangleBorder(
                       borderRadius: BorderRadius.circular(15.0),
                     ),
                     context: context,
                     builder: (BuildContext context) {

                       return Container(
                         padding: EdgeInsets.symmetric(horizontal: 13,vertical: 3),
                         decoration: BoxDecoration(
                           borderRadius: BorderRadius.only(topRight: Radius.circular(8),topLeft: Radius.circular(8))
                         ),

                         child: Center(
                           child: SingleChildScrollView(
                             child: Column(
                               mainAxisAlignment: MainAxisAlignment.start,
                               crossAxisAlignment: CrossAxisAlignment.start,
                               children:[
                                 Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Text('Filters',style: TextStyle(fontSize: 20,fontFamily: 'poppins'),),
                                     IconButton(
                                       icon : Icon(
                                         Icons.highlight_off_outlined,
                                       ), onPressed: () {
                                         Closepop(context);
                                     },
                                     ),
                                   ],
                                 ),
                                 SizedBox(height: 10,),
                                 Text('By Price',style: TextStyle( fontFamily: 'poppins',fontSize: 16),),
                                 SizedBox(height: 10,),
                             RangeSlider(
                               values: _values,
                               onChanged: (RangeValues values) {
                                 setState(() {
                                   setState(() {

                                   _values = values;
                                   });
                                 });
                               },
                             ),

                             SizedBox(height: 20,),


                                 Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                     Container(
                                        decoration: BoxDecoration(
                                          border: Border.all(color: UiColors.lightgrey),
                                              borderRadius: BorderRadius.circular(3),
                                          ),
                                       padding: EdgeInsets.symmetric(horizontal: 5),
                                       width: MediaQuery.of(context).size.width*0.38,
                                       height: 35,
                                       child: DropdownButton<String>(

                                         isExpanded : true,
                                         value: _chosenValue,
                                         underline: SizedBox(),
                                         style: TextStyle(color: Colors.black,  fontFamily: 'poppins',fontSize: 14,),
                                         items: <String>[
                                           'Min',
                                           '100',
                                           '500',
                                           '1000',

                                         ].map<DropdownMenuItem<String>>((String selectval) {
                                           return DropdownMenuItem<String>(
                                             value: selectval,
                                             child:  Text(selectval, style: TextStyle(color: Colors.black,  fontFamily: 'poppins',fontSize: 14,),),
                                           );
                                         }).toList(),


                                         icon: Icon(
                                           Icons.keyboard_arrow_down,
                                           color: Colors.grey,
                                         ),
                                         onChanged: (String? selectval) {
                                           setState(() {
                                             FocusScope.of(context).requestFocus(new FocusNode());
                                             selectval=selectval;
                                             _chosenValue=selectval!;

                                           });

                                         },
                                       ),
                                     ),
                                     Text('To',style: TextStyle(fontFamily: 'poppins',fontSize: 18),),
                                     Container(
                                       decoration: BoxDecoration(
                                         border: Border.all(color: UiColors.lightgrey),
                                         borderRadius: BorderRadius.circular(3),
                                       ),
                                       padding: EdgeInsets.symmetric(horizontal: 5),
                                       width: MediaQuery.of(context).size.width*0.38,

                                       height: 35,
                                       child: DropdownButton<String>(

                                         isExpanded : true,
                                         value: _chosenValue,
                                         underline: SizedBox(),
                                         style: TextStyle(color: Colors.black,  fontFamily: 'poppins',fontSize: 14,),
                                         items: <String>[
                                           'Min',
                                           '100',
                                           '500',
                                           '1000',

                                         ].map<DropdownMenuItem<String>>((String selectval) {
                                           return DropdownMenuItem<String>(
                                             value: selectval,
                                             child:  Text(selectval, style: TextStyle(color: Colors.black,  fontFamily: 'poppins',fontSize: 14,),),
                                           );
                                         }).toList(),


                                         icon: Icon(
                                           Icons.keyboard_arrow_down,
                                           color: Colors.grey,
                                         ),
                                         onChanged: (String? selectval) {
                                           setState(() {
                                             FocusScope.of(context).requestFocus(new FocusNode());
                                             selectval=selectval;
                                             _chosenValue=selectval!;

                                           });

                                         },
                                       ),
                                     ),


                                   ],
                                 ),
                                 SizedBox(height: 25,),
                                 Text('Brand',style: TextStyle( fontFamily: 'poppins',fontSize: 16),),
                                 SizedBox(height: 10,),
                                 Container(
                                   decoration: BoxDecoration(
                                     border: Border(bottom: BorderSide(color: UiColors.lightgrey)),

                                   ),
                                   padding: EdgeInsets.symmetric(horizontal: 5),
                                     height: 35,
                                   child: DropdownButton<String>(

                                     isExpanded : true,
                                     value: _chosenValue,
                                     underline: SizedBox(),
                                     style: TextStyle(color: Colors.black,fontSize: 14,),
                                     items: <String>[
                                       'Min',
                                       '100',
                                       '500',
                                       '1000',

                                     ].map<DropdownMenuItem<String>>((String selectval) {
                                       return DropdownMenuItem<String>(
                                         value: selectval,
                                         child:  Text(selectval, style: TextStyle(color: Colors.black, fontSize: 15,),),
                                       );
                                     }).toList(),


                                     icon: Icon(
                                       Icons.keyboard_arrow_down,
                                       color: Colors.grey,
                                     ),
                                     onChanged: (String? selectval) {
                                       setState(() {
                                         FocusScope.of(context).requestFocus(new FocusNode());
                                         selectval=selectval;
                                         _chosenValue=selectval!;

                                       });

                                     },
                                   ),
                                 ),

                                 SizedBox(height: 25,),
                                 Text('Primary Colors',style: TextStyle( fontFamily: 'poppins',fontSize: 16),),
                                 SizedBox(height: 10,),
                                 Row(
                                   children: [
                                     Container(
                                       decoration:BoxDecoration(
                                           shape: BoxShape.circle,
                                           border: Border.all()
                                       ),
                                       child: Padding(
                                         padding: const EdgeInsets.all(4.0),
                                         child: Container(
                                           decoration: BoxDecoration(
                                               shape: BoxShape.circle,
                                               color: Colors.red
                                           ),
                                           height: 25,width: 25,
                                         ),
                                       ),
                                     ),
                                     SizedBox(width: 15,),
                                     Container(
                                       decoration: BoxDecoration(
                                           shape: BoxShape.circle,
                                           color: Colors.blue
                                       ),
                                       height: 25,width: 25,
                                     ),
                                     SizedBox(width: 15,),
                                     Container(
                                       decoration: BoxDecoration(
                                           shape: BoxShape.circle,
                                           color: Colors.green
                                       ),
                                       height: 25,width: 25,
                                     ),
                                     SizedBox(width: 15,),
                                     Container(
                                       decoration: BoxDecoration(
                                           shape: BoxShape.circle,
                                           color: Colors.limeAccent
                                       ),
                                       height: 25,width: 25,
                                     ),
                                   ],
                                 ),

                                 SizedBox(height: 25,),
                                 UiButton(text: 'Apply', ontap: (){})
                               ],
                             ),
                           ),
                         ),
                       );
                     },
                   );
                 },
                 icon:  Icon(
                   Icons.tune_outlined,
                   color: UiColors.primary,
                 ),
             ),
              SizedBox(width: 10,)
            ],

          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [

                  GridView(
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      physics: BouncingScrollPhysics(),


                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 10,
                          mainAxisSpacing:10.0
                      ),
                      children:  [
                        for(int i=0; i<12; i++)
                          ProductCardSec(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                        ProductCardSec(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),


                      ]

                  ),
                ],
              ),
            ),
          ),
        ));
  }

}

