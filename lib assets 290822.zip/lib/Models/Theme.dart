import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
class UiColors {
  static const Color primaryShade = Color(0xffecedf2);
  static const Color primarySec = Color(0xffc8cedd);
  static const Color black = Color(0xFF4d4d4d);
  static const Color scaffold = Color(0xFDFDFEFF);
  static const Color container2 = Color(0xffeff1fa);
  static const Color BottomNavDarkmode = Color(0xff1f1d2b);
  static const Color darkmodeScaffold = Color(0xff252836);
  static const Color primary = Color(0xff7c8aaf);
  static const Color gradient2 = Color(0xff827bed);
  static const Color gradient1 = Color(0xffa894e6);
  static const Color Text3 = Color(0xff8c93b0);
  static const Color Shadow_Clr = Color(0x70e2e1e1);
  static const Color grey2 = Color(0xff6b6b6b);
  static const Color drawerDarkmode = Color(0xff252836);
  static const Color containerDarkmode = Color(0xff323542);
   static const Color error = Color.fromARGB(255, 255, 4, 4);
    static const Color success = Color.fromARGB(255, 30, 226, 27);
    static const Color white=Colors.white;
}
errortoast(text){
  
  return Fluttertoast.showToast(
            msg:text,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: UiColors.error,
            textColor: UiColors.white,
            fontSize: 16.0
        );
}
successtoast(text){
  
  return Fluttertoast.showToast(
            msg:text,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: UiColors.success,
            textColor: UiColors.white,
            fontSize: 16.0
        );
}
Closepop(context){
Navigator.of(context).pop(null);
}