import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'package:onshop/Models/Countries.dart';
import 'package:onshop/Models/Theme.dart';
import 'package:onshop/Views/Home/Home.dart';
import 'package:onshop/Views/SignUp/LoginPage.dart';
import 'package:onshop/Views/SignUp/PersonalDetailsPage.dart';
import 'package:onshop/main.dart';
 


final AppTheme = GetStorage();
final MedTempStorage = GetStorage();
final ShopStorage=GetStorage();
class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  getCountryName() async {
   var response = await http.get(Uri.parse("http://ip-api.com/json"),);

   setState(() {
      
    var userdatas = json.decode(response.body);
     print("userdatas");
     print(userdatas);
      MedTempStorage.write('CountryName', '${userdatas['countryCode']}');

   });
   if(MedTempStorage.read('CountryName')==null){
     

   }
   else{
      
     for(int i=0;i<Shopcountry.countries.length;i++){
       if(Shopcountry.countries[i]['code']==MedTempStorage.read('CountryName')){
         setState(() {
           MedTempStorage.write('Countryfullname', Shopcountry.countries[i]['name'].toString());
           MedTempStorage.write('max_length', Shopcountry.countries[i]['max_length'].toString());
           MedTempStorage.write('dial_code', "+${Shopcountry.countries[i]['dial_code'].toString()}");
           MedTempStorage.write('CountryName', Shopcountry.countries[i]['code'].toString());
         
         });
       }
     }
      
   }
  }
  void initState() {
   ShopStorage.erase();
  
       if(AppTheme.read('mode')==null){
     setState(() {
       AppTheme.write('mode', "0");
     });
     runApp(MyApp());
   }
     if(MedTempStorage.read('dial_code')==null || MedTempStorage.read('dial_code')=='null'){
      getCountryName();
    }
       Timer(Duration(seconds: 2), () {
         navigateFromSplash();
       });
    super.initState();
     
  }
  void dispose() {
     
    super.dispose();

  }
  
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 50.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    RichText(text: TextSpan(
                      text: 'Welcome to ',
                      style: TextStyle(fontSize: 24,fontFamily: 'semi bold',color:   Colors.black  ),
                      children: [
                        TextSpan(text: 'MedEqp',style: TextStyle(fontSize: 24,fontFamily: 'semi bold',color: UiColors.primary),
                        )
                      ]

                    )),

                    Center(child: SvgPicture.asset('assets/svgs/DNA.svg',color: UiColors.primary,height: 300,)),
                  /*  if(ShopStorage.read('mob')==null)
                    InkWell(
                        onTap: (){
                          if(ShopStorage.read('mob')==null){
                          Navigator.pushAndRemoveUntil(
                                              context, MaterialPageRoute(builder: (context) => LoginScreen()),
                                                  (Route<dynamic> route) => false,
                                            );
                          }
                          else{
                         Navigator.pushAndRemoveUntil(
                                              context, MaterialPageRoute(builder: (context) => HomePage()),
                                                  (Route<dynamic> route) => false,
                                            );
                          }
                        },
                        child: MedButton(text: 'Login',)),
                    if(ShopStorage.read('mob')!=null)*/
                      SizedBox()
                  ],
            ),
          ),
        ),
      ),
    );
  }

    navigateFromSplash () async {
    if(ShopStorage.read('mob')==null){
      Navigator.pushAndRemoveUntil(
        context, MaterialPageRoute(builder: (context) => LoginScreen()),
            (Route<dynamic> route) => false,
      );
    }
    else{
      if(ShopStorage.read('u_name')==null){
            Navigator.pushAndRemoveUntil(
                  context, MaterialPageRoute(builder: (context) => PersonalDetailsPage()),
                      (Route<dynamic> route) => false,
                );
   
      }
      else{
        Navigator.pushAndRemoveUntil(
          context, MaterialPageRoute(builder: (context) => Home()),
              (Route<dynamic> route) => false,
        );
      }
     
    }
  }
}
