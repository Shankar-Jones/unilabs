import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:onshop/Models/HeadingText.dart';
import 'package:onshop/Models/ProductCard.dart';
import 'package:onshop/Models/Theme.dart';

import 'ProductDetails.dart';



String category='1';
bool favorite = false;
class BaseScreen extends StatefulWidget {
  const BaseScreen({Key? key}) : super(key: key);

  @override
  _BaseScreenState createState() => _BaseScreenState();
}

class _BaseScreenState extends State<BaseScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height:20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 30,
                          foregroundImage: AssetImage('assets/profile.jpg'),
                        ),
                        SizedBox(width: 20,),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Welcome',style: TextStyle(color: Colors.black54,)),
                            Text('Jack Jones',style: TextStyle(color: Colors.black,fontSize: 17),),
                          ],
                        )
                      ],
                    ),
                    SvgPicture.asset('assets/homepage/notification.svg',height: 25,),
                  ],
                ),
                SizedBox(height:15),


                Padding(
                  padding: const EdgeInsets.symmetric(horizontal:  0,vertical: 15),
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                      color: UiColors.primaryShade,
                      borderRadius: BorderRadius.circular(9)
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 0),
                        child: TextFormField(
                          style: TextStyle(fontSize: 18),
                          decoration: InputDecoration(
                            hintText: ' Search your product...',
                            hintStyle: TextStyle(color:Colors.grey[400]),
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height:10),

                HeadingText1(text: 'Categories'),
                SizedBox(height:15),

                Container(
                  width: double.infinity,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child:Row(
                      children: [
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              category='1';
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color:category=='1' ? UiColors.primary : UiColors.primaryShade ,
                                  borderRadius: BorderRadius.circular(7)
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                                child: Text('All',style: TextStyle(color:category=='1' ? Colors.white :Colors.black),),
                              ),
                            ),
                          ),
                        ),

                        GestureDetector(
                          onTap: (){
                            setState(() {
                              category='2';
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color:category=='2' ? UiColors.primary : UiColors.primaryShade ,
                                  borderRadius: BorderRadius.circular(7)
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                                child: Text('Chair',style: TextStyle(color:category=='2' ? Colors.white :Colors.black),),
                              ),
                            ),
                          ),
                        ),

                        GestureDetector(
                          onTap: (){
                            setState(() {
                              category='3';
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color:category=='3' ? UiColors.primary : UiColors.primaryShade ,
                                  borderRadius: BorderRadius.circular(7)
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                                child: Text('Sofa',style: TextStyle(color:category=='3' ? Colors.white :Colors.black),),
                              ),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: (){
                            setState(() {
                              category='4';
                            });
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  color:category=='4' ? UiColors.primary : UiColors.primaryShade ,
                                  borderRadius: BorderRadius.circular(7)
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 35),
                                child: Text('Table',style: TextStyle(color:category=='4' ? Colors.white :Colors.black),),
                              ),
                            ),
                          ),
                        ),



                      ],
                    ),
                  ),
                ),

                SizedBox(height:20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    HeadingText1(text: 'New Arrivals'),
                    Row(
                      children: [
                        Text('Show all',style: TextStyle(color: UiColors.primary,),),
                        Icon(Icons.keyboard_arrow_right_outlined,color: UiColors.primary,)
                      ],
                    )
                  ],
                ),

                SizedBox(height:20),

                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      InkWell(
                          onTap: (){
                            Navigator.of(context).push(MaterialPageRoute(builder: (context)=> ProductDetails()));
                          },
                          child: ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322')),
                      ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://w7.pngwing.com/pngs/572/702/png-transparent-chair-chair-png-transparent-image-isolated-image-transparent-background-remove-the-background-product-image-free-image-clipping-path-clipping-paths.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),


                    ],
                  ),
                ),
                SizedBox(height:20),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    HeadingText1(text: 'Best Sellers'),
                    Row(
                      children: [
                        Text('Show all',style: TextStyle(color: UiColors.primary,),),
                        Icon(Icons.keyboard_arrow_right_outlined,color: UiColors.primary,)
                      ],
                    )
                  ],
                ),

                SizedBox(height:20),

                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: BouncingScrollPhysics(),
                  child: Row(
                    children: [

                      ProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://thumbnail.imgbin.com/11/6/24/imgbin-modern-sofa-67qvYz0tCSVTStgkxdhNRMkzS_t.jpg',productName: 'Armchair',productPercentage: 48,icon: Icons.favorite_border_outlined,productRate: '3,322'),
                      ProductCard(ImageUrl: 'https://toppng.com/uploads/preview/old-chair-11530974949teyhc2owch.png',productName: 'Armchair',productPercentage: 48,icon:Icons.favorite_border_outlined ,productRate: '3,322'),

                    ],
                  ),
                ),
                SizedBox(height:20),

              ],
            ),
          ),
        ),
          bottomNavigationBar: Container(
            height: 80,
            decoration: BoxDecoration(
              color: UiColors.primaryShade,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(25),topRight: Radius.circular(25))
            ),
            child: Center(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SvgPicture.asset('assets/homepage/home.svg',height: 45 ),
                  SvgPicture.asset('assets/homepage/category.svg',height: 45  ),
                  SvgPicture.asset('assets/homepage/mycart.svg',height: 45  ),
                  SvgPicture.asset('assets/homepage/favourite.svg',height: 45  ),
                  SvgPicture.asset('assets/homepage/profile.svg',height: 45  ),

                ],
              ),
            ),
          ),
        ));
  }

}
