class ConstantsN{
 static String baseurl="https://us-central1-medical-eq.cloudfunctions.net";
 static String currency="\$";
 static String currencyin="\u{20B9}";
 static String versionkeyforuno='4BD708248551961946010EFB603EFF81446EDD29637474F85677CD016B2C1C1D';
}
